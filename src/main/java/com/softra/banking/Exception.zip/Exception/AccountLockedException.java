package com.softra.banking.Exception;

public class AccountLockedException extends Exception {
	public AccountLockedException(String msg) {
		super(msg);
	}
}
